package com.teoria2;

public class Principal {

	public static void main(String[] args) {

		HacerCocina cocina = new HacerCocina();
		
		cocina.Limpiar();
		
		
		
	}

}
