package com.teoria2;

public interface Casa {

	public void Limpiar();
	public void Recojer();
	public void Dormir();

	
	
}
