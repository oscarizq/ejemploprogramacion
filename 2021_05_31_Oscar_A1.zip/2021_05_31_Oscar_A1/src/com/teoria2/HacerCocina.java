package com.teoria2;


public class HacerCocina implements Casa {

	public void Limpiar(){
		System.out.println("Limpiar cocina");
		
	}
	
	public void Recojer(){
		System.out.println("Limpiar salon");
		
	}
	
	public void Dormir(){
		System.out.println("Limpiar dormitorio");
		
	}



	
}
