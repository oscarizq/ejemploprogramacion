//no funcina bucle infinito


package com.teoria3;

import java.util.Scanner;

public class Numerosecreto {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);

		 int a = (int) ((Math.random() * 100)+1); 
		 int b;
		 int i; 
		 int contador = 0;
		 boolean x = false;
		 
		 double posInf = Double.POSITIVE_INFINITY;
		 
		 System.out.println("El juego consiste en averiguar un n�mero secreto de 100 posibles.");

		 System.out.print("No tienes limite de intentos");
		 
		 do {
			 for (i=0; i<=posInf; i++) { 
				 
				 sc = new Scanner(System.in);
				 System.out.println("Introduce numero");
				 b = sc.nextInt();
				 
		    
				 if (a == b) {  
					 System.out.println("�Has acertado!"); 
					 x = true;
					 break;
				 }else{
					contador+=1;
					System.out.println("Incorrecto");
		    	  	if (a > b) {
		    	  		System.out.println("El n�mero secreto es MAYOR que " + b);
		    	  	}
		       		else {
		       			System.out.println("El n�mero secreto es MENOR que " + b);
				      
		 			}
				    
		      }
		  
		    
		    }
			 
		 }
		 while(x = false);
		 System.out.println("N� de intetos "+contador);
	}
}

