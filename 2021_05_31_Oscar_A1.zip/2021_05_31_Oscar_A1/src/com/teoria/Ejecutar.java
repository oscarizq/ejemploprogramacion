package com.teoria;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Ejecutar {

	public static void main(String[] args) {

		//crea dos hijos con los siguientes datos 
		
		Date fecha = new Date();
		Date fechama�ana = new Date(fecha.getTime() + TimeUnit.DAYS.toMillis( 1 ));
		
		Hijo hija1 = new Hijo("juan",123.456f, fecha, "madrid", 15);
		Hijo hija2 = new Hijo("maria",321.654f, fechama�ana, "sevilla", 18);
		
		System.out.println(hija1.toString());
		System.out.println(hija2.toString());
		
		//juan, madrid, 15, 123.456f, fechahoy
		
		//maria, servilla, 18, 321.654f,fechama�ana
		
		//el padre NO se puede crear �como lo resuelves?
		
		//Muestra en consola los datos de los dos hijos
		
		
		
		
		
	}

}
